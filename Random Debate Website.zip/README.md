
  # Random Debate Website

  This is a code bundle for Random Debate Website. The original project is available at https://www.figma.com/design/2QTpakZtXhFjV37G9650Y7/Random-Debate-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  