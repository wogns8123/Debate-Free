package com.example.debate_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebateBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
